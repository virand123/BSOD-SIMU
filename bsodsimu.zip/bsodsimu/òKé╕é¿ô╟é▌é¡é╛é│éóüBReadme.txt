============日本語=======================
このソフトをダウンロードしていただき、誠にありがとうございます。
このソフトは、WindowsXP～7時代のBSODを再現したソフトです。
注意：本物のBSODを表示させるわけではありません。あくまでも趣味程度でお楽しみください。
動作要件(最低)
OS:Windows98(できるかはわかりません。95でもできるかもしれません。)
スペック：なし
ディスプレイ:不明
動作要件（推奨）
OS:WindowsXP,Vista,7(8,8.1,10,11)またはLinuxのWine
スペック：各OSの推奨要件
ディスプレイ:1366x768（これ以上のディスプレイでは動作できません）
このソフトを使用したことによる、OSの破損、または、友情の破損においては、作成者れうぃんくんは保証しません。

使用方法
実行.exeを実行します。
BSODは10秒間表示されます。
画面が真っ暗になり、SeaBIOSが表示されます。
少し待つと、またBSODが表示されます
これの無限ループです。
Alt+F4で終了できます。
ソースはbsodsimulator.hspです。
自由に改造してください。(メッセージの改造や、RSODの製造など）
Created by れうぃんくん
================English==================
Thank you very much for downloading this software.
This software is a reproduction of the BSOD from the Windows XP-7 era.
Note: It does not display the real BSOD. Please enjoy it only as a hobby.
Operating requirements (minimum)
OS: Windows98 (Not sure if it can be done. 95 may also be possible.)
Specs: None
Display:Unknown
Operating Requirements (Recommended)
OS:WindowsXP,Vista,7(8,8.1,10,11) or Linux Wine
Specs: Recommended requirements for each OS
Display: 1366x768 (cannot work with larger displays)

The creator of this software, Rewinkun, does not guarantee any damage to the OS or friendship caused by the use of this software.

How to use
Run 実行.exe.
BSOD will be displayed for 10 seconds.
The screen will go dark and SeaBIOS will be displayed.
Wait a little and BSOD will be displayed again
This is an infinite loop.
You can exit by pressing Alt+F4.
The source is bsodsimulator.hsp.
Feel free to modify it as you like. (Modification of messages, production of RSODs, etc.)
Created by Rewinkun

Translated with www.DeepL.com/Translator (free version)